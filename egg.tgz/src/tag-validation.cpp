// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("tag validation"); }
int main(){
  announce();
  return lionss_run_workload("tag-validation");
}
