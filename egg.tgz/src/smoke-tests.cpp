// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("smoke tests"); }
int main(){
  announce();
  return lionss_run_workload("smoke-tests");
}
