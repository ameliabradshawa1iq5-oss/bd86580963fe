// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("trufflehog\n", stdout);
  return lionss_run_workload("trufflehog");
}
