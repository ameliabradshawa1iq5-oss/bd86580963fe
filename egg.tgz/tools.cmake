# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(codeblock-run src/codeblock-run.cpp)
set_property(TARGET codeblock-run PROPERTY CXX_STANDARD 11)
target_link_libraries(codeblock-run lionss pthread)

add_executable(clang-trunk src/clang-trunk.cpp)
set_property(TARGET clang-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-trunk lionss pthread)

add_executable(unused-includes src/unused-includes.cpp)
set_property(TARGET unused-includes PROPERTY CXX_STANDARD 11)
target_link_libraries(unused-includes lionss pthread)

add_executable(abi-stability src/abi-stability.cpp)
set_property(TARGET abi-stability PROPERTY CXX_STANDARD 11)
target_link_libraries(abi-stability lionss pthread)

add_executable(feature-flags-matrix src/feature-flags-matrix.cpp)
set_property(TARGET feature-flags-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(feature-flags-matrix lionss pthread)

add_executable(msan src/msan.cpp)
set_property(TARGET msan PROPERTY CXX_STANDARD 11)
target_link_libraries(msan lionss pthread)

add_executable(binary-size src/binary-size.cpp)
set_property(TARGET binary-size PROPERTY CXX_STANDARD 11)
target_link_libraries(binary-size lionss pthread)

add_executable(gcc-12 src/gcc-12.cpp)
set_property(TARGET gcc-12 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-12 lionss pthread)

add_executable(mingw-build src/mingw-build.cpp)
set_property(TARGET mingw-build PROPERTY CXX_STANDARD 11)
target_link_libraries(mingw-build lionss pthread)

add_executable(clang-analyzer src/clang-analyzer.cpp)
set_property(TARGET clang-analyzer PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-analyzer lionss pthread)

add_executable(multilib-build src/multilib-build.cpp)
set_property(TARGET multilib-build PROPERTY CXX_STANDARD 11)
target_link_libraries(multilib-build lionss pthread)

add_executable(scoop-manifest src/scoop-manifest.cpp)
set_property(TARGET scoop-manifest PROPERTY CXX_STANDARD 11)
target_link_libraries(scoop-manifest lionss pthread)

add_executable(trufflehog src/trufflehog.cpp)
set_property(TARGET trufflehog PROPERTY CXX_STANDARD 11)
target_link_libraries(trufflehog lionss pthread)

add_executable(concepts-check src/concepts-check.cpp)
set_property(TARGET concepts-check PROPERTY CXX_STANDARD 11)
target_link_libraries(concepts-check lionss pthread)

add_executable(transitive-deps src/transitive-deps.cpp)
set_property(TARGET transitive-deps PROPERTY CXX_STANDARD 11)
target_link_libraries(transitive-deps lionss pthread)

add_executable(markdown-lint src/markdown-lint.cpp)
set_property(TARGET markdown-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown-lint lionss pthread)

add_executable(build-pic src/build-pic.cpp)
set_property(TARGET build-pic PROPERTY CXX_STANDARD 11)
target_link_libraries(build-pic lionss pthread)

add_executable(ccache-stats src/ccache-stats.cpp)
set_property(TARGET ccache-stats PROPERTY CXX_STANDARD 11)
target_link_libraries(ccache-stats lionss pthread)

add_executable(nanobench src/nanobench.cpp)
set_property(TARGET nanobench PROPERTY CXX_STANDARD 11)
target_link_libraries(nanobench lionss pthread)

add_executable(single-header-check src/single-header-check.cpp)
set_property(TARGET single-header-check PROPERTY CXX_STANDARD 11)
target_link_libraries(single-header-check lionss pthread)

add_executable(tag-validation src/tag-validation.cpp)
set_property(TARGET tag-validation PROPERTY CXX_STANDARD 11)
target_link_libraries(tag-validation lionss pthread)

add_executable(netbsd-build src/netbsd-build.cpp)
set_property(TARGET netbsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(netbsd-build lionss pthread)

add_executable(build-header-only src/build-header-only.cpp)
set_property(TARGET build-header-only PROPERTY CXX_STANDARD 11)
target_link_libraries(build-header-only lionss pthread)

add_executable(duplication-check src/duplication-check.cpp)
set_property(TARGET duplication-check PROPERTY CXX_STANDARD 11)
target_link_libraries(duplication-check lionss pthread)

add_executable(todo-scan src/todo-scan.cpp)
set_property(TARGET todo-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(todo-scan lionss pthread)

add_executable(google-benchmark src/google-benchmark.cpp)
set_property(TARGET google-benchmark PROPERTY CXX_STANDARD 11)
target_link_libraries(google-benchmark lionss pthread)

add_executable(grammar-fuzz src/grammar-fuzz.cpp)
set_property(TARGET grammar-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(grammar-fuzz lionss pthread)

add_executable(valgrind-helgrind src/valgrind-helgrind.cpp)
set_property(TARGET valgrind-helgrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-helgrind lionss pthread)

add_executable(spellcheck src/spellcheck.cpp)
set_property(TARGET spellcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(spellcheck lionss pthread)

add_executable(smoke-tests src/smoke-tests.cpp)
set_property(TARGET smoke-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(smoke-tests lionss pthread)

